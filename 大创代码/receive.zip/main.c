#include <reg52.h>
#include <intrins.h>

#define uint unsigned int
#define uchar unsigned char

sbit START = P1^0;
sbit DATA = P1^1;
sbit led = P2^1;

bit flag = 0;

void delay(uint i);
void start();
void receive(uint datas[]);
void stop();

void main(){
	uint xdata datas[20];
	uint i = 0;
	START = 1;
	while(1){
		start();
		receive(datas);
		stop();
		for(i = 0;i < 20;i++){
			led = datas[i];
			delay(50);
		}
	}

}
void delay(uint i){
	int j;
	for(j = 0;j < 10*i;j++){
		_nop_();
	}
}

void start(){
	flag = 1;
	START = 0;
	while(DATA);
	delay(10);
	while(!DATA);
	START = 1;
	delay(10);
}
	
void receive(uint datas[]){
	int i;
	for(i = 0;i < 20;i++){
		datas[i] = DATA;
		delay(10);
	}
}

void stop(){
	if(DATA == 1){
		flag = 0;
		delay(10);
	} else {
		flag = 1;
		START = 0;
	}
}
		