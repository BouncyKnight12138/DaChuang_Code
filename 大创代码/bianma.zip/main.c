#include <reg52.h>
#define uint unsigned int
	
sbit led = P1^0;

void processing(uint datas[], uint codes[]);
void extraction(uint newdata[], uint codes[]);
void delay(uint i);

void main(){
	while(1){
		int i;
		uint datas[20] = {0, 1, 0, 0, 0, 1, 1, 0, 0, 0, 1, 1, 0, 0, 1, 0, 0, 0, 1, 1};
		uint xdata codes[64], newdata[20];
		processing(datas, codes);
		codes[6] = 1;
		extraction(newdata, codes);
		for (i = 0; i < 20; i++) {
			led = newdata[i];
			delay(1000000);
		}
	}
}
	
void processing(uint datas[],uint codes[]){
  int i = 0;
  int flag = 0;
	//����λ����
  for (i = 63; i > 34; i--) {
    codes[i] = 0;
  }
  i = 0;
  for (flag = 0; flag < 5; flag++) {
		//���ݷ����λ��2��4��5��6λΪ����λ
    int first = flag * 7;
    codes[first + 6] = datas[i++];
    codes[first + 5] = datas[i++];
    codes[first + 4] = datas[i++];
    codes[first + 2] = datas[i++];
		//����У����λ
    codes[first] = codes[first + 2] ^ codes[first + 4] ^ codes[first + 6];
    codes[first + 1] = codes[first + 2] ^ codes[first + 5] ^ codes[first + 6];
    codes[first + 3] = codes[first + 4] ^ codes[first + 5] ^ codes[first + 6];
  }
}

void extraction(uint newdata[], uint codes[]) {
  int flag = 5;
  int i =0;
  for (flag = 0; flag < 5; flag++) {
    int first = flag * 7;
		//�ж��Ƿ��������������͸���
    if(((codes[first] ^ codes[first + 2] ^ codes[first + 4] ^ codes[first + 6]) != 0)
        ||((codes[first+1] ^ codes[first + 2] ^ codes[first + 5] ^ codes[first + 6]) != 0)
        ||((codes[first+3] ^ codes[first + 4] ^ codes[first + 5] ^ codes[first + 6]) != 0)){
      int S1 = codes[first + 3] ^ codes[first + 4] ^ codes[first + 5] ^ codes[first + 6];
      int S2 = codes[first + 1] ^ codes[first + 2] ^ codes[first + 5] ^ codes[first + 6];
      int S3 = codes[first + 0] ^ codes[first + 2] ^ codes[first + 4] ^ codes[first + 6];
      uint sum = S3 * 4 + S2 * 2 + S1;
      codes[first + sum -1] = ~(codes[first + sum -1]);
    } 
		//�ָ�����
    newdata[i++] = codes[first + 6];
    newdata[i++] = codes[first + 5];
    newdata[i++] = codes[first + 4];
    newdata[i++] = codes[first + 2];
  }
}

void delay(unsigned int i)
{
	while(i--);
}
