#include <reg52.h>
#include <intrins.h>

#define uint unsigned int
#define uchar unsigned char

sbit START = P1^0;
sbit DATA = P1^1;

bit flag = 0;

void delay(uint i);
void start();
void send(uint datas[]);
void stop();

void main(){
	uint xdata datas[20] = {0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1,1};
	while(1){
		if(START == 0){
			start();
			send(datas);
			stop();
		}
	}
}

void delay(uint i){
	int j;
	for(j = 0;j < 10*i;j++){
		_nop_();
	}
}

void start(){
	flag = 1;
	DATA = 0;
	delay(10);
	DATA = 1;
	delay(10);
}

void send(uint datas[]){
	if(flag == 1){
		int i = 0;
		while(!START);
		delay(10);
		for(i = 0;i < 20;i++){
			DATA = datas[i];
			delay(10);
		}
	}
}
	
void stop(){
	DATA = 1;
	delay(10);
	flag = 0;
}